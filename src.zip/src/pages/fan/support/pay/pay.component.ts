import { Component } from '@angular/core';

import { UserManager } from '../../../../api/providers/user';
import { ToastController } from 'ionic-angular/components/toast/toast-controller';
import { User } from '../../../../_models/user';
import { SecureStorageObject } from '@ionic-native/secure-storage';
import { NavParams } from 'ionic-angular/navigation/nav-params';
import { NativeStorage } from '@ionic-native/native-storage';

@Component({
  selector: 'page-pay-ionic',
  templateUrl: 'pay.component.html'
})
export class PayPage {
  mUser = new User(0, "", "", "", "", "", "", "", "", "", "");
  user = this.mUser.build();

  selectedUser = null;
  
  constructor(public uM: UserManager, public nS: NativeStorage, public tC: ToastController, public nP: NavParams) {
    this.selectedUser = nP.get("user");

    nS.getItem("user_id").then(data => {
        this.user.id = parseInt(data);
        
      });
      nS.getItem("name").then(data => {this.user.name = data;});
      nS.getItem("surname").then(data => {this.user.surname = data;});
      nS.getItem("email").then(data => {this.user.email = data;});
      nS.getItem("type").then(data => {this.user.type = data;});
      nS.getItem("avatar").then(data => {this.user.avatar = data;});
  }
  
}