import { Component, ViewChild } from '@angular/core';

import { Platform, MenuController, Nav } from 'ionic-angular';

import { LoginPage } from '../pages/auth/login.component';
import { JudgeMainPage } from '../pages/judge/judge.component';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { ScreenOrientation } from '@ionic-native/screen-orientation';
import { SecureStorage, SecureStorageObject } from '@ionic-native/secure-storage';
import { UserManager } from '../api/providers/user';
import { ToastController } from 'ionic-angular/components/toast/toast-controller';
import { TrainerMainPage } from '../pages/trainer/trainer.component';
import { SportsmanMainPage } from '../pages/sportsman/sportsman.component';
import { FanMainPage } from '../pages/fan/fan.component';
import { PopoverController } from 'ionic-angular';
import { MainPopover } from './main.popover';
import { PageTransition } from 'ionic-angular/transitions/page-transition';
import { ControlTournamentPage } from '../pages/judge/tournament/control/control.component';
import { NumberValueAccessor } from '@angular/forms/src/directives/number_value_accessor';
import { NavController } from 'ionic-angular/navigation/nav-controller';
import { NativeStorage } from '@ionic-native/native-storage';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  // make JudgeMainPage the root (or first) page
  
  rootPage = null;
  static title = "";
  isLogged = false;

  pages: Array<{title: string, component: any}>;

  constructor(
    public platform: Platform,
    public menu: MenuController,
    public statusBar: StatusBar,
    public splashScreen: SplashScreen,
    private userManager: UserManager,
    private screenOrientation: ScreenOrientation,
    private secureStorage: SecureStorage,
    public popoverCtrl: PopoverController,
    public toastCtrl: ToastController,
    public nativeStorage: NativeStorage
  ) {
    userManager.setTitle("MMA");
    this.initializeApp();

    this.nativeStorage.getItem('type').then(data => {
      this.toastCtrl.create({message: "Type is: " + data, duration: 3000}).present();
      this.isLogged = true;
      this.rootPage = JudgeMainPage;
        switch (data) {
          case "1": this.rootPage = JudgeMainPage; break;
          case "2": this.rootPage = TrainerMainPage; break;
          case "3": this.rootPage = SportsmanMainPage; break;
          case "4": this.rootPage = FanMainPage; break;
        }
    }, error => {
      this.rootPage = LoginPage;
    });

    //this.rootPage = LoginPage;
    //this.nav.push(this.rootPage);
    //this.nav.setRoot(this.rootPage);
    //this.userManager.controlPage(this.nav);
    /*this.secureStorage.create('user_settings').then((storage: SecureStorageObject) => {
      
      this.toastCtrl.create({message: "Type is: " + storage.secureDevice.name, duration: 3000}).present();
      storage.get("type").then(data => {
        this.isLogged = true;
        this.toastCtrl.create({message: "Type is: " + data, duration: 3000}).present();
        storage.get("fightGoing").then(data => {
          if (data == "1") {
            this.rootPage = ControlTournamentPage;
            //this.nav.push(this.rootPage);
            //this.nav.setRoot(this.rootPage);
          } else {
            this.rootPage = JudgeMainPage;
            switch (data) {
              case "1": this.rootPage = JudgeMainPage; break;
              case "2": this.rootPage = TrainerMainPage; break;
              case "3": this.rootPage = SportsmanMainPage; break;
              case "4": this.rootPage = FanMainPage; break;
            }
            //this.nav.push(this.rootPage);
            //this.nav.setRoot(this.rootPage);
          }
        }, err => {
          this.rootPage = JudgeMainPage;
          switch (data) {
            case "1": this.rootPage = JudgeMainPage; break;
            case "2": this.rootPage = TrainerMainPage; break;
            case "3": this.rootPage = SportsmanMainPage; break;
            case "4": this.rootPage = FanMainPage; break;
          }
          //this.nav.push(this.rootPage);
          //this.nav.setRoot(this.rootPage);
        });
        
      }, error => {
        this.rootPage = LoginPage;
        //this.nav.push(this.rootPage);
        //this.nav.setRoot(this.rootPage);
      });
    });*/
    
    // set our app's pages
    this.pages = [
      { title: 'Hello Ionic', component: JudgeMainPage },
      { title: 'My First List', component: LoginPage }
    ];
  }

  public static setTitle(t: string) {
    this.title = t;
  }

  presentPopover(event) {
    if (this.isLogged) {
      this.popoverCtrl.create(MainPopover).present({ev: event});
    }
  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      // this.statusBar.styleDefault();
      this.statusBar.overlaysWebView(true);
      this.statusBar.backgroundColorByHexString("#171A1C");
      
      //this.screenOrientation.lock(this.screenOrientation.ORIENTATIONS.PORTRAIT);

      this.splashScreen.hide();
    });
  }

  openPage(page) {
    // close the menu when clicking a link from the menu
    this.menu.close();
    // navigate to the new page if it is not the current page
    this.nav.setRoot(page.component);
  }
}
