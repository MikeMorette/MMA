import { Injectable } from '@angular/core';
import { HTTP } from '@ionic-native/http';

/**
 * Api is a generic REST Api handler. Set your API url first.
 */
@Injectable()
export class ApiA {
  url: string = 'http://n22.mikex.ru/v1';

  constructor(public http: HTTP) {
    //this.headers = new Headers();
    //this.headers.append("Authorization", 'MikeX_Az10TWlrZUxlZV9rZXkvY6BpL3NpdGUvYXBpw11jg2Mjk4OTIzNzg1ODIzNjc5');
    //this.headers.append("Accept", 'application/json');
    //this.headers.append('Content-Type', 'application/json' );
    //this.options = new RequestOptions({ headers: this.headers });
  }

  get(endpoint: string, params?: any) {
    /*let paramsObj = "?";
    if (params) {
      for (let k in params) {
        paramsObj += k + "=" + params[k] + "&";
      }
    }*/
    return this.http.get(this.url + '/' + endpoint, {}, {"Authorization": 'MikeX_Az10TWlrZUxlZV9rZXkvY6BpL3NpdGUvYXBpw11jg2Mjk4OTIzNzg1ODIzNjc5'});
  }

  post(endpoint: string, body: any) {
    return this.http.post(this.url + '/' + endpoint, body, {"Authorization": 'MikeX_Az10TWlrZUxlZV9rZXkvY6BpL3NpdGUvYXBpw11jg2Mjk4OTIzNzg1ODIzNjc5'});
  }

}
